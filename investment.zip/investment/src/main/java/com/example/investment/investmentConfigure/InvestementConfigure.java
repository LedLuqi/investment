package com.example.investment.investmentConfigure;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component("com.example.investment")
public class InvestementConfigure {
}
