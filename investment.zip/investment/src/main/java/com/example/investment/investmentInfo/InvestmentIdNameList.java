package com.example.investment.investmentInfo;

public class InvestmentIdNameList {

    private Long id;
    private String name;

    public InvestmentIdNameList(Long id, String name) {
        this.id = id;
        this.name = name;
    }

}
