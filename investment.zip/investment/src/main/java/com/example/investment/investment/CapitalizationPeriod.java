package com.example.investment.investment;

public enum CapitalizationPeriod { ONEMOUNTCH, THREEMOUNTCH, SIXMOUNTCH, ELEVENMOUNTCH
}
