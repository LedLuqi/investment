package com.example.investment.investmentCalculator;

import com.example.investment.investment.InvestmentService;
import com.example.investment.ivestmentReopsitories.InvestmentCalculatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InvestmentCaluclatorService {

    @Autowired
    InvestmentCalculatorRepository investmentCalculatorRepository;

    @Autowired
    InvestmentService investmentService;

    public InvestmentCaluclatorService() {
    }

    public void addCalculation (InvestmentCalculator investmentCalculator) {
        investmentCalculatorRepository.save(investmentCalculator);
    }

}
