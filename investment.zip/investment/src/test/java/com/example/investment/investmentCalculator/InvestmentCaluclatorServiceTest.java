package com.example.investment.investmentCalculator;

import org.junit.Test;

import static org.junit.Assert.*;

public class InvestmentCaluclatorServiceTest {

    @Test
    public void addCalculation() {
    }

    @Test
    public void getCalculationHistory() {
    }

    @Test
    public void getCalculationByInvestmentId() {
    }
}