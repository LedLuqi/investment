package com.example.investment.investmentInfo;

import org.junit.Test;

import static org.junit.Assert.*;

public class InvestmentInfoTest {

    @Test
    public void update() {
    }
}